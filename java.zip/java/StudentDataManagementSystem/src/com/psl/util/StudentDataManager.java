package com.psl.util;

//Override all the methods of the DataManager Interface
public class StudentDataManager implements DataManager {

	
}
