package com.psl.employee;


public class Employee  {

	static int employeeId;
	int employeeSalary;
	String employeeName;

	static {
		System.out.println("Static block 1");
	}

	static {
		System.out.println("Static block 2");
	}

	public Employee(String employeeName, int employeeSalary) {

		// TODO Auto-generated constructor stub
		System.out.println("Constructor");
		employeeId++;

		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}

	static void showEmployee() {
		// TODO Auto-generated method stub

		System.out.println("show emp");
		System.out.println("Emp is:-" + employeeId);
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Emp is:-" + employeeId + employeeName + employeeSalary;
	}

	public static void main(String[] args) {

	//	System.out.println("Inside main");

		Employee e1 = new Employee("Minu", 80000);

	//	e1.showEmployee();

		System.out.println(e1);

	/*	Employee e2 = new Employee("bulbul", 90000);

		e2.showEmployee();

		Employee e3 = new Employee("Shilpa", 100000);

		e3.showEmployee();

		System.out.println(e1.employeeId);

		Employee.showEmployee();*/
	}

}
