package com.psl.employee;

public class Developer extends Employee {

	public Developer(String employeeName, int employeeSalary) {
		super(employeeName, employeeSalary);
		// TODO Auto-generated constructor stub
	}

	
}
