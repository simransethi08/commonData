package com.psl.gen;

public class GenericsDemo<E> {

	E obj;

	public GenericsDemo(E obj) {
		// TODO Auto-generated constructor stub

		this.obj = obj;
	}

	public void setObj(E obj) {
		this.obj = obj;
	}

	public E getObj() {
		return obj;
	}

	public static void main(String[] args) {

		GenericsDemo<String> o1 = new GenericsDemo<String>("PSL");

		GenericsDemo<Integer> o2 = new GenericsDemo<Integer>(new Integer(10));
		
		GenericsDemo<Integer> o3 = new GenericsDemo<Integer>(new Integer(10));


		String oo1 = o1.getObj();
		
		System.out.println(oo1);
		
		Integer i1=o2.getObj();
		
		
		System.out.println(i1);
		
		
		
		
		
		
	}
}
