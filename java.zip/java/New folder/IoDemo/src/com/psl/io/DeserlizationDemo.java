package com.psl.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeserlizationDemo {

	public static void main(String[] args) {

		try {
			FileInputStream fis = new FileInputStream("test.ser");

			ObjectInputStream ois = new ObjectInputStream(fis);

			Employee e = (Employee) ois.readObject();

			e.displayDetails();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
