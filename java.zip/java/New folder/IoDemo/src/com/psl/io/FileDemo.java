package com.psl.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class FileDemo {

	public static void main(String[] args) {

		File f = new File("test.txt");

		if (f.exists()) {
			System.out.println("file exists");
		} else {
			System.out.println("File dosen't exists...creating ...");

			try {
				f.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		/*
		 * System.out.println(f.getName()); System.out.println(f.getPath());
		 * 
		 * System.out.println(f.getAbsolutePath());
		 * 
		 * System.out.println(f.isDirectory()); System.out.println(f.canRead());
		 * System.out.println(f.canWrite());
		 */
		/*
		 * FileOutputStream fos = null; try {
		 * 
		 * String str = "Ariting into a file...Yo Yo...!!!";
		 * 
		 * fos = new FileOutputStream(f); fos.write(str.getBytes());
		 * 
		 * } catch (FileNotFoundException e) { // TODO Auto-generated catch
		 * block e.printStackTrace(); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } finally { try {
		 * fos.flush(); fos.close(); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 * 
		 * }
		 */

		FileInputStream fis = null;
		try {
			fis = new FileInputStream(f);

			// BufferedReader br = new BufferedReader(new
			// InputStreamReader(fis));

			// String str = null;

			Scanner sc = new Scanner(f);

			sc.useDelimiter(",");
			String i = null;

			while (sc.hasNext()) {
				i = sc.next();
				System.out.println(i);
			}

			/*String arr[]=i.split(",");
			
			for (String string : arr) {
				System.out.println(string);
			}*/
			
			// System.out.println(str);

			/*
			 * int i = 0;
			 * 
			 * while ((i = fis.read()) != -1) { System.out.print((char) i);
			 * 
			 * }
			 */

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
