package com.psl.io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerilizationDemo {

	public static void main(String[] args) {
		
		
		Employee e1=new Employee(118,"xyz",70000);
		
		
		try {
			FileOutputStream fos =new FileOutputStream("test.ser");
			
			ObjectOutputStream oos =new ObjectOutputStream(fos);
			
			oos.writeObject(e1);
			
			System.out.println("done");
			
			fos.close();
			oos.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
