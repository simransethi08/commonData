package com.psl.collection;

public class Employee /* implements Comparable<Employee> */{

	int employeeId, employeeSalary;
	String employeeName;
	Coffee c;

	/*
	 * public Employee(int employeeId, String employeeName, int employeeSalary)
	 * {
	 * 
	 * this.employeeId = employeeId;
	 * 
	 * this.employeeName = employeeName; this.employeeSalary = employeeSalary; }
	 */

	void displayDetails() {
		// TODO Auto-generated method stub

		System.out.println("show emp");
		System.out.println("Emp is:-" + employeeId + employeeName
				+ employeeSalary);
	}

	@Override
	public int hashCode() {
		
		return employeeId*31;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (employeeId != other.employeeId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Emp is:-" + employeeId + employeeName;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public int getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public void setC(Coffee c) {
		this.c = c;
	}

	public Coffee getC() {
		return c;
	}

	/*
	 * @Override public int compareTo(Employee o) { // TODO Auto-generated
	 * method stub
	 * 
	 * int i = 0;
	 * 
	 * if (this.getEmployeeId() > o.getEmployeeId()) { i = 1; } else if
	 * (this.getEmployeeId() < o.getEmployeeId()) { i = -1; } else { i = 0; }
	 * 
	 * return i;
	 * 
	 * }
	 */

}
