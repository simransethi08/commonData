package com.psl.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TreeSetDemo {

	public static void main(String[] args) {

		Employee e1 = new Employee();
		e1.setEmployeeId(103);
		e1.setEmployeeName("naseef");

		Employee e2 = new Employee();
		e2.setEmployeeId(105);
		e2.setEmployeeName("sakshi");

		Employee e3 = new Employee();
		e3.setEmployeeId(101);
		e3.setEmployeeName("gunda");

		Employee e4 = new Employee();
		e4.setEmployeeId(102);
		e4.setEmployeeName("sheanan");

		// Set<Employee> ts= new TreeSet<Employee>();
		List<Employee> ts = new ArrayList<Employee>();

		ts.add(e1);
		ts.add(e2);
		ts.add(e3);
		ts.add(e4);

		System.out.println("Before Sorting" + ts);

//		Collections.sort(ts);

//		System.out.println("After Sorting by id" + ts);

		Collections.sort(ts, new SortByName());

		System.out.println("After Sorting by name" + ts);

		Collections.sort(ts,new Comparator<Employee>() {
			
			@Override
			public int compare(Employee o1, Employee o2) {
				// TODO Auto-generated method stub
				int i = 0;

				if (o1.getEmployeeSalary() > o2.getEmployeeSalary()) {
					i = 1;
				} else if (o1.getEmployeeSalary() < o2.getEmployeeSalary()) {
					i = -1;
				} else {
					i = 0;
				}

				return i;
			}
		});
		
		System.out.println("Sort by Salary" + ts);
	}
}
