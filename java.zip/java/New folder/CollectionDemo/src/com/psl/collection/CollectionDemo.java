package com.psl.collection;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class CollectionDemo {

	public static void main(String[] args) {

		Employee e1 = new Employee();
		e1.setEmployeeId(101);
		e1.setEmployeeName("Shubham");
		e1.setC(Coffee.small);

		Employee e2 = new Employee();
		e2.setEmployeeId(102);
		e2.setEmployeeName("Raj");

		Employee e3 = new Employee();
		e3.setEmployeeId(103);
		e3.setEmployeeName("Amit");

		Employee e4 = new Employee();
		e4.setEmployeeId(104);
		e4.setEmployeeName("Sourav");

		Employee e5 = new Employee();
		e5.setEmployeeId(105);
		e5.setEmployeeName("Simran");

		ArrayList<Employee> listEmp = new ArrayList<Employee>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);
		listEmp.add(e5);

		ArrayList<Employee> arre1 = new ArrayList<Employee>();
		ArrayList<Employee> arre2 = new ArrayList<Employee>();
		ArrayList<Employee> arre3 = new ArrayList<Employee>();

		for (Employee employee : listEmp) {

			if (employee.getC() == Coffee.small) {
				arre1.add(employee);
			} else if (employee.getC() == Coffee.regular) {
				arre2.add(employee);
			} else {
				arre3.add(employee);
			}

		}

		/*
		 * if (e1.getC() == Coffee.small) { arre1.add(e1); arre1.add(e3); }
		 * 
		 * arre2.add(e2); arre2.add(e5);
		 * 
		 * arre3.add(e4);
		 */

		Map<Coffee, ArrayList<Employee>> arr = new TreeMap<Coffee, ArrayList<Employee>>();

		arr.put(Coffee.small, arre1);
		arr.put(Coffee.regular, arre2);
		arr.put(Coffee.large, arre3);

		/*
		 * arr.put(Coffee.small, "ashish");
		 * 
		 * arr.put(Coffee.small, "Amit");
		 * 
		 * arr.put(Coffee.large, "Raj");
		 */

		// System.out.println(arr.get(3));

		/*
		 * System.out.println(arr.remove(4)); System.out.println(arr);
		 * 
		 * Collections.reverse(arr); System.out.println(arr);
		 * 
		 * Collections.shuffle(arr);
		 */
		/*
		 * System.out.println(arr);
		 * 
		 * Iterator<Integer> it = arr.keySet().iterator();
		 */

		/*
		 * Set<Entry<Integer, String>> set=arr.entrySet();
		 * 
		 * 
		 * Iterator<Entry<Integer, String>> it1=set.iterator();
		 */

		//Map.Entry<, V>
		
		Set<Entry<Coffee, ArrayList<Employee>>> set= arr.entrySet();
		
		Iterator<Entry<Coffee, ArrayList<Employee>>> itt=set.iterator();
		
		while (itt.hasNext()) {
			System.out.println(itt.next().getKey()+ );
		}
		
		
		
		
		
		
		for (Entry<Coffee, ArrayList<Employee>> entry : arr.entrySet()) {
			System.out.println(entry.getKey() + "" + entry.getValue());

		}

		/*
		 * while (it.hasNext()) {
		 * 
		 * int i = it.next(); System.out.println(i);
		 * 
		 * System.out.println(arr.get(i));
		 * 
		 * }
		 */

	}
}
