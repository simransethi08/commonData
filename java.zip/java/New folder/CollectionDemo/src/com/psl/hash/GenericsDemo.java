package com.psl.hash;

import java.util.ArrayList;
import java.util.List;

import com.psl.collection.Employee;

public class GenericsDemo {

	public static void main(String[] args) {

		List<Vehicle> vList = new ArrayList<Vehicle>();

		List<FourWheeler> fourList = new ArrayList<FourWheeler>();

		List<TwoWheeler> twoList = new ArrayList<TwoWheeler>();

		List<Tesla> tList = new ArrayList<Tesla>();
		
		List<Employee> eList = new ArrayList<Employee>();

		show(vList);
		show(fourList);
		show(twoList);
		show(tList);
		show(eList);
		

	}

	private static void show(List<? super FourWheeler> v) {
		// TODO Auto-generated method stub

	}
}
