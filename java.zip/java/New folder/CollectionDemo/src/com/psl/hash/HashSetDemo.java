package com.psl.hash;

import java.util.HashSet;
import java.util.Set;

import com.psl.collection.Employee;

public class HashSetDemo {

	public static void main(String[] args) {

		Employee e1 = new Employee();
		e1.setEmployeeId(103);
		e1.setEmployeeName("naseef");

		Employee e2 = new Employee();
		e2.setEmployeeId(105);
		e2.setEmployeeName("sakshi");

		Employee e3 = new Employee();
		e3.setEmployeeId(101);
		e3.setEmployeeName("gunda");

		Employee e4 = new Employee();
		e4.setEmployeeId(102);
		e4.setEmployeeName("sheanan");

		Employee e5 = new Employee();
		e5.setEmployeeId(101);
		e5.setEmployeeName("gunda");

		Set<Employee> set = new HashSet<Employee>();

		set.add(e1);
		set.add(e2);
		set.add(e3);
		set.add(e4);
		set.add(e5);

		System.out.println(set);

	}
}
