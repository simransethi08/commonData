package com.psl.hash;

public class Vehicle {

	public Vehicle() {
		// TODO Auto-generated constructor stub
		System.out.println("Vehicle");
	}
}


class FourWheeler extends Vehicle{
	
	public FourWheeler() {
		// TODO Auto-generated constructor stub
		System.out.println("FourWheeler");
	}
}

class TwoWheeler extends Vehicle{
	
	public TwoWheeler() {
		// TODO Auto-generated constructor stub
		
		System.out.println("Two Wheeler");
	}
}



class Tesla extends FourWheeler{
	public Tesla() {
		// TODO Auto-generated constructor stub
		
		System.out.println("Tesla");
	}
	
}