package com.psl.thread;

@interface MyCity{
	
	String cityName();
}


@MyCity(cityName = "Pune")
public class Account {

	
	int balance;

	public Account(int bal) {
		// TODO Auto-generated constructor stub
		balance = bal;

	}

	@Deprecated
	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}
}
