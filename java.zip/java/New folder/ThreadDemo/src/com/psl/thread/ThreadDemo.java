package com.psl.thread;

public class ThreadDemo implements Runnable {

	public static void main(String[] args) throws InterruptedException {

		System.out.println("inside main");
		ThreadDemo obj = new ThreadDemo();

		Thread t1 = new Thread(obj, "one");
		Thread t2 = new Thread(obj, "two");

		// t1.join();

		t1.start();

		t2.start();

		// t1.stop();
		// t2.join();
		// t1.join();

		t1.setPriority(1);
		t2.setPriority(10);

		System.out.println(t1.isAlive());
		System.out.println(t2.isAlive());
		System.out.println("end main");
	}

	@Override
	public void run() {

		// System.out.println("Inside run");
		for (int i = 1; i <= 10; i++) {
			// TODO Auto-generated method stub

			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (Thread.currentThread().getName().equals("one")) {

				System.out.println("one" + ""
						+ Thread.currentThread().getPriority());

			} else {
				System.out.println("two" + ""
						+ Thread.currentThread().getPriority());
			}
		}
	}
}
