package com.psl.wait;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;

public class WaitNoti extends JFrame implements Runnable {

	int bx = 10, blx = 10, px = 10;

	public WaitNoti() {
		// TODO Auto-generated constructor stub

		setVisible(true);
		setSize(600, 600);

	}

	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		super.paint(g);

		g.setColor(Color.BLUE);
		g.fillOval(bx, 50, 50, 50);

		g.setColor(Color.BLACK);
		g.fillOval(blx, 150, 50, 50);

		g.setColor(Color.PINK);
		g.fillOval(px, 250, 50, 50);
	}

	public static void main(String[] args) {

		WaitNoti obj = new WaitNoti();

		Thread t1 = new Thread(obj, "blue");

		Thread t2 = new Thread(obj, "black");

		Thread t3 = new Thread(obj, "pink");

		t1.start();

		t2.start();

		t3.start();
	}

	@Override
	public void run() {
		while (true) {
			// TODO Auto-generated method stub
			try {
				if (Thread.currentThread().getName().equals("blue")) {

					if(bx==300){
						synchronized (this) {
							wait();
						}
					}
					
					Thread.sleep(20);
					bx++;
									
				} else if (Thread.currentThread().getName().equals("black")) {
					if(blx==300){
						synchronized (this) {
							wait();
						}
					}
					Thread.sleep(40);
					blx++;
				} else {
					
					if(px==300){
						synchronized (this) {
							notify();
						}
					}
					Thread.sleep(100);
					px++;
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			repaint();
		}
	}
}
