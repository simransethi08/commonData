import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class Test {
	public static void main(String[] args) throws ClassNotFoundException {
		Student student1 = new Student(1, "Mahesh", 5, 'A');
		Student student2 = new Student(2, "Suresh", 5, 'B');
		Student student3 = new Student(3, "Meena", 5, 'A');
		Student student4 = new Student(4, "Teena", 5, 'B');
		Student student5 = new Student(5, "Bunty", 5, 'C');
		
		try {
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("data.txt"));
			objectOutputStream.writeObject(student1);
			objectOutputStream.writeObject(student2);
			objectOutputStream.writeObject(student3);
			objectOutputStream.writeObject(student4);
			objectOutputStream.writeObject(student5);
			objectOutputStream.close();
			
			
			ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream("data.txt"));
			
			Student st=(Student)inputStream.readObject();
			
			System.out.println(st);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
