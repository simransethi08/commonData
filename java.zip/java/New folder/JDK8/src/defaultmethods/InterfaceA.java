package defaultmethods;

public interface InterfaceA {
	public default void method1(){
		System.out.println("Method1 of InterfaceA");
	}
	
	public static void method2(){
		System.out.println("Hello World");
	}
}
