
public interface MyNumber {
	public int getNum();
}
