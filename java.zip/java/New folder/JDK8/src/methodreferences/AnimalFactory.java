package methodreferences;

import java.util.List;

public interface AnimalFactory {
	public Animal getAnimal(List<Animal> animals);
}
