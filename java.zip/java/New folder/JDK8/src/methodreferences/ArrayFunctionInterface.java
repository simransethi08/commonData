package methodreferences;

public interface ArrayFunctionInterface {
	int[] intArrMaker(int noOfEle);
}
