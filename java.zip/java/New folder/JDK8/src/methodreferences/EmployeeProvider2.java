package methodreferences;

public interface EmployeeProvider2 {
	Employee getEmployee();
}


class EmployeeProvider implements EmployeeProvider2{

	@Override
	public Employee getEmployee() {
		Employee emp = new Employee();
		return emp;
	}
	
}