package annotations;

/* Java Program Example - Java Type Annotations 
*  This program demonstrate several type annotations */

import java.lang.annotation.*;
import java.lang.reflect.*;

/* a marker annotation that can be applied to a type */
@Target(ElementType.TYPE_USE)
@interface TypeAnnotat { }

/* another marker annotation that can be applied to a type */
@Target(ElementType.TYPE_USE)
@interface NotZeroLen { }

/* still another marker annotation that can be applied to a type */
@Target(ElementType.TYPE_USE)
@interface Unique { }

/* a parameterized annotation that can be applied to a type */
@Target(ElementType.TYPE_USE)
@interface MaxLen {
	int value();
}

/* an annotation that can be applied to a type parameter */
@Target(ElementType.TYPE_PARAMETER)
@interface What {
	String description();
}

/* an annotation that can be applied to a field declaration */
@Target(ElementType.FIELD)
@interface EmptyOK { }

/* an annotation that can be applied to a method declaration */
@Target(ElementType.METHOD)
@interface Recommended { }

/* use an annotation on a type parameter */
public class AnnotationDemo1<@What(description = "Generic data type") T> {

	/* use a type annotation on a constructor */
	public @Unique AnnotationDemo1() { }
	
	/* annotate the type (in this case String), not the field */
	@TypeAnnotat String str;
	
	/* this annotates the field test */
	@EmptyOK String test;
	
	/* use a type annotation to annotate this (the receiver) */
	public int fun(@TypeAnnotat AnnotationDemo1<T> this, int x) {
		return 10;
	}
	
	/* annotate the return type */
	public @TypeAnnotat Integer fun2(int j, int k) {
		return j+k;
	}
	
	/* annotate the method declaration */
	public @Recommended Integer fun3(String str) {
		return str.length() / 2;
	}
	
	/* use a type annotation with a throws clause */
	public void fun4() throws @TypeAnnotat NullPointerException {
		// ...
	}
	
	/* annotate array levels */
	String @MaxLen(10) [] @NotZeroLen [] w;
	
	/* annotate the array element type */
	@TypeAnnotat Integer[] vec;
	
	public static void myMethod(int i) {
		
		/* use a type annotation on a type argument */
		AnnotationDemo1<@TypeAnnotat Integer> obj = new AnnotationDemo1<@TypeAnnotat Integer>();
		
		/* use a type annotation with new */
		@Unique AnnotationDemo1<Integer> obj2 = new @Unique AnnotationDemo1<Integer>();
		
		Object x = new Integer(10);
		Integer y;
		
		/* use a type annotation on a cast */
		y = (@TypeAnnotat Integer) x;
	}
	
	public static void main(String args[])
	{
		myMethod(10);
	}
	
	/* use type annotation with inheritance clause */
	class MyClass extends @TypeAnnotat AnnotationDemo1<Boolean> { }
}