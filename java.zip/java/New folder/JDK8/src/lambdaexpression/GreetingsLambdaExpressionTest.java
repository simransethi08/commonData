package lambdaexpression;
/*
 * Lambda expression eliminates the need of defining a class that implements Greetings interface
 */
public class GreetingsLambdaExpressionTest {
	public static void main(String[] args) {
		//one parameter without parenthesis
		Greetings greet1 = name -> System.out.println("Hello " + name); 
		//System.out.println("Welcome");
				
		//one parameter with parenthesis
		Greetings greet2 = (name) -> System.out.println("Hello " + name);
		
		greet1.greet("World");
		greet2.greet("World");
	}
}
