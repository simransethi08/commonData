package lambdaexpression;

import com.sun.org.apache.bcel.internal.generic.RETURN;

/*
 * This is functional interface
 * Implementation of this function depends on the requirement.
 * It may add, subtract, multiply or divide the numbers passed to it
 */
public interface Operations {
	public int operation(int x, int y);
}


class Demo{
	
	public static void main(String[] args) {
		
		Operations op = (int x, int y) -> x+y;
		
		Operations op1 = (x,y) -> x+y;
		
		Operations op2 = (x,y) -> {return x+y;};
		
		
		
		System.out.println(op.operation(10, 20));
		
	}
}