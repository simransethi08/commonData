package lambdaexpression;

public interface Polygon {
	public void calcArea(double... b);
}
