package lambdaexpression;

interface Animal {
	public void speak();
}

public class Demo {

	public static void main(String[] args) {

		Animal an = () -> System.out.println("dog");

		an.speak();
	}
}
