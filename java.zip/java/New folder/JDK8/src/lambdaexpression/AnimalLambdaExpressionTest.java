package lambdaexpression;

public class AnimalLambdaExpressionTest {
	public static void main(String[] args) {
		
		//with no parameters
		Animal cat = () -> System.out.println("MEAW");
		
		Animal dog = () -> System.out.println("BARK");
		
		Animal lion = () -> System.out.println("Roar");
		
		cat.speak();
		dog.speak();
		lion.speak();
	}
}
