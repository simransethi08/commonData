package lambdaexpression;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class PersonMain {
	public static void main(String[] args) {
		
		Comparator<Person> c=new Comparator<Person>() {
			
			@Override
			public int compare(Person o1, Person o2) {
				// TODO Auto-generated method stub
				return 0;
			}
		};
		
		
		Comparator<Person> byName = 
				(Person p1, Person p2)->p1.getName().compareTo(p2.getName());
				
				
				Collections.sort(new ArrayList<Person>(), byName);
	}
}
