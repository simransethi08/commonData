public class Test {
	final static short x=2;
	final static int y = 0;
	public static void main(String[] args) {
					for (int z=0; z<3; z++){
						System.out.println("Value of z is: " + z);
					switch (z){		
					
					case y: {System.out.println("0"+" "+z+" "+y);break;}
					case x-1: {System.out.println("1"+" "+z+" "+(x-1));break;}
					case x: {System.out.println("2"+" "+z+" "+x);break;}
					}
			}
		}
	}