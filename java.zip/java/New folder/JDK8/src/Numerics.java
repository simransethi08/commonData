
public class Numerics {
	public static void main(String[] args) {
		String num = "12_34";
		int n1 = 12_90;
		
		System.out.println(n1);
		int n = Integer.parseInt(num);
		System.out.println("Number is: " + n);
	}
}
