
public class LambdaTest {
	public static void main(String[] args) {
		MyNumber number = () ->  10;
		System.out.println(number.getNum());
	}
}
