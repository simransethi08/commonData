package com.psl.wrapper;

public class WrapperDemo {

	public static void main(String[] args) {

		int a = 10;

		Integer i = new Integer(a);

		Integer i1 = a; //

		System.out.println(i);

		int aa = i.intValue();

		int a2 = i;

		System.out.println(aa);

		String str = "10 ";

		int a1 = Integer.parseInt(str);

		System.out.println(a1);

		String str1 = String.valueOf(10);

	}
}
