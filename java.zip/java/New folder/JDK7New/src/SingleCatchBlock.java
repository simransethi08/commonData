import java.io.FileInputStream;
import java.io.FileOutputStream;

public class SingleCatchBlock {
	public static void main(String[] args) {
		int b =10, x[] = { 10, 20, 30 };
		
		
		
		try(FileInputStream fis=new FileInputStream("");
			FileOutputStream fos=new FileOutputStream("");	
				) { 
			int c = x[0]/b; 
			System.out.println(c);
			String str = "hello";
			System.out.println(str.charAt(15));
		}  catch(ArithmeticException | ArrayIndexOutOfBoundsException 
				| StringIndexOutOfBoundsException  e) { 
			System.out.println(e); 
		} catch(Exception e){
			e.printStackTrace();
		}
	}
}