import java.util.ArrayList;
import java.util.List;


public class CollectionDemo {
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("ABC");
		list.add("12");
	}
}
