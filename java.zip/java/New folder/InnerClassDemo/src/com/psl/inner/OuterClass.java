package com.psl.inner;

public class OuterClass {

	private int a = 10;

	void displayOuter() {
		// TODO Auto-generated method stub

		System.out.println("Outer Class method");
	}

	public static void main(String[] args) {

		// OuterClass obj = new OuterClass();

		OuterClass obj = new OuterClass() {
			@Override
			void displayOuter() {
				// TODO Auto-generated method stub
				 super.displayOuter();
				System.out.println("new display outer method");

			}
		};

		obj.displayOuter();

	}
}
