package com.psl.bo;

import com.psl.vo.EmployeeTo;

public class EmployeeBo {

	public void displayEmp(EmployeeTo obj) {
		// TODO Auto-generated method stub

		//obj=new 
		
		System.out.println(obj.getEmployeeId());

	}

}
