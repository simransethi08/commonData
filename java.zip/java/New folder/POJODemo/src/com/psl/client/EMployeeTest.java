package com.psl.client;

import com.psl.bo.EmployeeBo;
import com.psl.vo.EmployeeTo;

public class EMployeeTest {

	public static void main(String[] args) {

		int empId=105;
		
		int fempId=105+2;
		
		
		EmployeeTo obj = new EmployeeTo();

		
		
		
		obj.setEmployeeId(fempId);
		
		obj.setEmployeeName("xyz");
		
		obj.setEmployeeSalary(80000);
		
		
		
		EmployeeBo empObj=new EmployeeBo();
		
		empObj.displayEmp(obj);
		
		
	}
}
