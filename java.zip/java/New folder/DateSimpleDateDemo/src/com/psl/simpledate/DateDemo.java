package com.psl.simpledate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateDemo {

	public static void main(String[] args) {

		Date d = new Date();

		System.out.println(d);

		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

		String str = sdf.format(d);

		System.out.println(str);

		String d1 = "11-04-2017";

		Date d2 = null;
		try {
			d2 = sdf.parse(d1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(d2);
		
		java.sql.Date ds= new java.sql.Date(d2.getTime());
		
		System.out.println(ds);
		
		//Calendar cal =Calendar.getInstance();
		
		
		//cal.setLenient(true);
		
		Calendar cal1= new GregorianCalendar();
		
		cal1.setTime(d);
		

		
		cal1.set(Calendar.DATE, 17);
		
		
		cal1.add(Calendar.DATE, -7);
		
		
		System.out.println(cal1.get(Calendar.DAY_OF_WEEK));
		
		System.out.println(sdf.format(cal1.getTime()));		
		
		

	}
}
