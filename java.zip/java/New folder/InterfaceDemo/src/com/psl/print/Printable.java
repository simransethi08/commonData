package com.psl.print;

public interface Printable {

	int a = 10;

	public abstract void print();
}
