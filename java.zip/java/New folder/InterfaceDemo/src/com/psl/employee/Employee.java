package com.psl.employee;

import com.psl.print.Printable;

public class Employee implements Printable {

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("print in employee");
		
		System.out.println(a);
	}
}
