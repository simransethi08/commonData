package com.psl.controller;

import com.psl.employee.Employee;
import com.psl.print.Printable;
import com.psl.vehicle.Vehicle;

public class InterfaceDemo {

	public static void main(String[] args) {

		Printable p = new Employee();

		p.print();

		Printable p1 = new Vehicle();

		p1.print();
	}
}
