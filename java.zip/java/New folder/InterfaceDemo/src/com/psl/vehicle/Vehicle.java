package com.psl.vehicle;

import com.psl.print.Printable;

public class Vehicle implements Printable{

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("print in vehicle");
	}
	
}
