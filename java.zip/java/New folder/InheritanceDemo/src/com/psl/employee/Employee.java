package com.psl.employee;

public class Employee {

	 int employeeId,employeeSalary;
	 String employeeName;

	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	public Employee(int employeeId,String employeeName, int employeeSalary) {

		this.employeeId = employeeId;

		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}

	
	
	void displayDetails() {
		// TODO Auto-generated method stub

		System.out.println("show emp");
		System.out.println("Emp is:-" + employeeId + employeeName
				+ employeeSalary);
	}

	/*
	 * @Override public String toString() { // TODO Auto-generated method stub
	 * return "Emp is:-" + employeeId + employeeName + employeeSalary; }
	 */
	
	
	void showEmp() {
		// TODO Auto-generated method stub
		System.out.println("show emp");
	}

}
