package com.psl.employee;

public class Client {

	private void add(int a, int b) {
		// TODO Auto-generated method stub

		int result = a + b;
		System.out.println(result);

	}

	private void add(int... a) {
		// TODO Auto-generated method stub

		int result = 0;
		for (int i = 0; i < a.length; i++) {

			result = result + a[i];

		}

		System.out.println();
	}

	private void add(int a, int b, int c) {
		// TODO Auto-generated method stub
		int result = a + b + c;
		System.out.println(result);
	}

	public static void main(String[] args) {

		Employee d = new Developer(107, "james bond", 100000, 10000, 5000, 5000);

		d.displayDetails();

		d.showEmp();
		
		
		EmployeeTO obj =new EmployeeTO();
		
		obj.setEmployeeId(108);
		
		System.out.println(obj.getEmployeeId());

		// d.showDeveloper();

	}
}
