package com.psl.employee;

public class Developer {

	int pf = 5000, ta = 10000, food = 5000;

	/*public Developer(int employeeId, String employeeName, int employeeSalary,
			int pf, int ta, int food) {
		super(employeeId, employeeName, employeeSalary);
		// TODO Auto-generated constructor stub

		this.pf = pf;
		this.ta = ta;
		this.food = food;
	}*/

	public Developer() {
		// TODO Auto-generated constructor stub

	}

	
	void displayDetails(EmployeeTO obj) {
		// TODO Auto-generated method stub
		/*super.displayDetails();
		int netSalary = employeeSalary + pf + ta + food;*/

		System.out.println("Developer :-" + employeeName + netSalary);

	}
	
	void showDeveloper() {
		// TODO Auto-generated method stub
		System.out.println("show dev");
	}

}
