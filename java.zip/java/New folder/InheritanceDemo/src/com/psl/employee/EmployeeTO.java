package com.psl.employee;

public class EmployeeTO {

	private int employeeId,employeeSalary;
	private String employeeName;
	
	
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	
	public int getEmployeeId() {
		return employeeId;
	}
	
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	public String getEmployeeName() {
		return employeeName;
	}
	
	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	public int getEmployeeSalary() {
		return employeeSalary;
	}
}
