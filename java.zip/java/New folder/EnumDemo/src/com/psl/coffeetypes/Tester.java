package com.psl.coffeetypes;

import java.util.ArrayList;
import java.util.List;

interface Chewable {
}

class Meat implements Chewable {
}

public class Tester {
	public static void main(String[] args) {
		List<? extends Chewable> list1 = new ArrayList<Meat>(); // Line 11
		List<Chewable> list2 = new ArrayList<Chewable>(); // Line 13
		Meat meat = new Meat();
		list1.add(meat); // Line 17
		list2.add(meat); // Line 19
	}
}