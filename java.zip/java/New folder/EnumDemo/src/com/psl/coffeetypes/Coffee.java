package com.psl.coffeetypes;

public enum Coffee {

	small(50), regular(80), large(120);

	int price;

	Coffee(int price) {
		this.price = price;
	}
	
	public int getPrice() {
		return price;
	}

}
