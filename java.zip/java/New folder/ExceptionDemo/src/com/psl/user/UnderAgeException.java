package com.psl.user;

public class UnderAgeException extends Exception {

	public UnderAgeException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
		
		//System.out.println("Age less than 18");
	}
	
	
}
