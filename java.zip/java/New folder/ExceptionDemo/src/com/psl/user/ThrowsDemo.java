package com.psl.user;

public class ThrowsDemo {

	private void validateAge(int age) throws UnderAgeException{
		// TODO Auto-generated method stub

		if (age < 18) {

			throw new UnderAgeException("Age less than 18");

		} else {
			System.out.println("Looks good...");
		}

	}

	public static void main(String[] args)  {

		int age = 10;

		try {
			new ThrowsDemo().validateAge(age);
		} catch (UnderAgeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		assert age > 18 : "Invalid Age...";
		
		
		
		System.out.println("mehtod 2 ...4");
		

	}
}
