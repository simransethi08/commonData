package com.psl.exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ExceptionDemo {

	private void display() {
		// TODO Auto-generated method stub

		System.out.println("display");
	}

	public static void main(String[] args) throws  IOException {

		int a = 10, b = 2, result = 0;

		ExceptionDemo obj = null;

		try {
			result = a / b;

			obj.display();

			System.out.println("Result :-" + result);

		} catch (ArithmeticException ae) {
			// TODO Auto-generated catch block
			// e.printStackTrace();

			System.out.println("dude you can not divide by 0....");

			b = 2;

			result = a / b;

			System.out.println("Very good:-" + result);

			try(FileInputStream fis =new FileInputStream("");
				FileOutputStream fos= new FileOutputStream("")	) {

			} catch (FileNotFoundException | NullPointerException | ArithmeticException e) { // TODO:
																		// handle
																		// exception

				obj = new ExceptionDemo();
				obj.display();

			} finally {
				System.out.println("execute always...!!!");
			}

			System.out.println("Looks good...go ahead...:-)");

		}
	}
}
