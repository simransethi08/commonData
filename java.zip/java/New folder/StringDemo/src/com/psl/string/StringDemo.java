package com.psl.string;

import java.util.StringTokenizer;

public class StringDemo {

	public static void main(String[] args) {

		String str = "Persistent";
		
		String str1 = "Persistent";

		String str2 = new String("Persistent");

		String str3 = new String("Persistent");
		
		
	//	str = "PSL";
		
	/*	System.out.println(str.equals(str2));
		
		System.out.println(str==str1);
		
		System.out.println(str==str2);
		
		System.out.println(str2==str3);
		
		str.concat("Systems Ltd.");
		
		System.out.println(str);*/
		
		
		StringTokenizer token=new StringTokenizer("Persistent system ltd.");
		
		while (token.hasMoreElements()) {
			
			System.out.println(token.nextToken());	
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
