package com.psl.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JDBCDemo {

	public static void main(String[] args) {

		try {
			Class.forName("com.mysql.jdbc.Driver");

			System.out.println("Driver loaded");

			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/testdb", "root", "root");

			System.out.println("got connection");

			Statement cst = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					

			/*
			 * Scanner sc = new Scanner(System.in);
			 * System.out.println("Enter Id:-"); int id = sc.nextInt();
			 * 
			 * System.out.println("Enter Name:-"); String name = sc.next();
			 */

			/*
			 * pstmt.setInt(1, id); pstmt.setString(2, name);
			 */

			ResultSet rs = cst.executeQuery("select * from emp");
			
			
			rs.next();
			System.out.println(rs.getInt(1) + rs.getString(2));
			rs.relative(2);
			System.out.println(rs.getInt(1) + rs.getString(2));
			//rs.relative(rows)
			
			System.out.println(rs.isFirst());
			System.out.println(rs.isLast());
			
			rs.relative(-1);
			System.out.println(rs.getInt(1) + rs.getString(2));

		//	rs.first();
			
		//	System.out.println(rs.getInt(1) + rs.getString(2));

			/*while (rs.next()) {
				
			}*/

			cst.close();
			conn.close();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
