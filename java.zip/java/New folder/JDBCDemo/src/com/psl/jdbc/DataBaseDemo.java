package com.psl.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DataBaseDemo {

	public static void main(String[] args) {

		try {

			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded");

			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/testdb", "root", "root");

			// conn.setAutoCommit(false);

			Statement stmt = conn.createStatement();

			String query1 = "insert into emp values(121,'ironman')";

			String query2 = "insert into emp values(131,'superman')";

			String query3 = "insert into emp values(121,'spiderman')";

			stmt.addBatch(query1);
			stmt.addBatch(query2);
			stmt.addBatch(query3);

			int i[] = stmt.executeBatch();

			System.out.println("data inserted");

			// conn.setAutoCommit(true);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
