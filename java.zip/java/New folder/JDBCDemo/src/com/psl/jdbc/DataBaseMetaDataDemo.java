package com.psl.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.DatabaseMetaData;

public class DataBaseMetaDataDemo {

	public static void main(String[] args) {

		try {

			Class.forName("com.mysql.jdbc.Driver");

			System.out.println("Driver loaded");
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/testdb", "root", "root");

			java.sql.DatabaseMetaData db = conn.getMetaData();

			System.out.println(db.getDatabaseProductName());
			System.out.println(db.getDatabaseProductVersion());

			Statement stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery("select * from emp");

			ResultSetMetaData rsdb = rs.getMetaData();
			
			int i = rsdb.getColumnCount();
			
			
			System.out.println(i);
			
			for (int j = 1; j <= i; j++) {
				System.out.println(rsdb.getColumnName(j));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("got connection");

	}
}
