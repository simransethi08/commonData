package com.psl.shape;

public abstract class Shape {

	public abstract void calculateArea();

	public void displayShape() {
		// TODO Auto-generated method stub
		System.out.println("Display Shape");
	}

}
