package com.psl.shape;

public class Circle extends Shape {

	float area, r;

	public Circle(int r) {
		// TODO Auto-generated constructor stub
		this.r = r;
	}

	@Override
	public void calculateArea() {
		// TODO Auto-generated method stub

		area = 3.14f * r * r;

		System.out.println("Area of circle:-" + area);
	}

}
