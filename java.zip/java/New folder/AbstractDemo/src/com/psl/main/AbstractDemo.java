package com.psl.main;

import com.psl.shape.Circle;
import com.psl.shape.Shape;

public class AbstractDemo {

	public static void main(String[] args) {

		Shape s = new Circle(10);

		s.calculateArea();
		s.displayShape();
	}
}
