Select CategoryName, Description 
from Categories
order by CategoryName;

Select ContactName, CompanyName, ContactTitle ,Phone 
from Customers
order by Phone;

Select firstname, lastname, hiredate
FROM employees
order by hiredate desc;

SELECT  OrderID, OrderDate, ShippedDate, CustomerID, Freight
FROM orders
order by freight desc;



Select CompanyName, Fax, Phone, HomePage ,Country from Suppliers
order by country desc,companyname;
 
 
 SELECT title ,firstname,lastname
 from employees
 where title like 'Sales Representative';
 
 SELECT title ,firstname,lastname
 from employees
 where title not like 'Sales Representative';
 
 Select companyname,contactname FROM customers
 where city like 'Buenos Aires';
 
 
Select productname , unitprice,quantityperunit FROM products
where unitsinstock =0;


Select orderdate ,shippeddate ,customerid, freight
from orders 
where orderdate = '19-May-97';

Select firstname, lastname, country
FROM employees
where country not like 'USA';

Select titleofcourtesy,firstname, lastname
FROM employees
where titleofcourtesy in('Mrs.','Ms.');

Select titleofcourtesy,firstname, lastname
FROM employees
where titleofcourtesy like 'M%';


Select concat(concat(firstname, ' '), lastname)
from employees;
