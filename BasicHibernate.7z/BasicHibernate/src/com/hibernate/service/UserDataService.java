package com.hibernate.service;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.dto.UserData;

public class UserDataService {
	public static void main(String[] args) {
		UserData data=new UserData();
		data.setUserId(1);
		data.setUserName("Sim");
		SessionFactory sf=new Configuration().configure("hibernate2.cfg.xml").buildSessionFactory();
		Session session =sf.openSession();
		session.beginTransaction();
		session.save(data);
		session.getTransaction().commit();
		session.close();
	}

}
